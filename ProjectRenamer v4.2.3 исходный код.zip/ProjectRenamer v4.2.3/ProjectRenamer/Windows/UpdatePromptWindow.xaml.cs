﻿using ProjectRenamer.Helpers;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ProjectRenamer.Windows
{
    public partial class UpdatePromptWindow : Window
    {
        public UpdateInfo LatestUpdate { get; private set; }

        public UpdatePromptWindow(List<UpdateInfo> updates)
        {
            InitializeComponent();

            if (updates == null || updates.Count == 0)
            {
                Close();
                return;
            }

            LatestUpdate = updates[updates.Count - 1]; // Последняя версия для скачивания

            // Отображаем все обновления от старых к новым
            for (int i = updates.Count - 1; i >= 0; i--)
            {
                var update = updates[i];

                var border = new Border
                {
                    Background = (Brush)Application.Current.Resources["ContainerBackground"],
                    CornerRadius = new CornerRadius(8),
                    Padding = new Thickness(15),
                    Margin = new Thickness(0, 0, 0, 10)
                };

                var stack = new StackPanel();

                var title = new TextBlock
                {
                    Text = $"Версия {update.LatestVersion}",
                    FontSize = 14,
                    FontWeight = FontWeights.Bold,
                    Foreground = (Brush)Application.Current.Resources["TextPrimary"],
                    Margin = new Thickness(0, 0, 0, 5)
                };

                // ✅ Обрабатываем переносы строк из GitHub Markdown
                string cleanNotes = string.IsNullOrEmpty(update.ReleaseNotes)
                    ? "Список изменений не указан."
                    : update.ReleaseNotes
                        .Replace("\\r\\n", "\n")   // Экранированные \r\n
                        .Replace("\\n", "\n")      // Экранированные \n
                        .Replace("\r\n", "\n")     // Реальные \r\n
                        .Replace("\r", "\n");      // Одиночные \r

                var notes = new TextBlock
                {
                    Text = cleanNotes,
                    TextWrapping = TextWrapping.Wrap,
                    FontSize = 12,
                    Foreground = (Brush)Application.Current.Resources["TextSecondary"]
                };

                stack.Children.Add(title);
                stack.Children.Add(notes);
                border.Child = stack;

                spUpdates.Children.Add(border);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }
    }
}