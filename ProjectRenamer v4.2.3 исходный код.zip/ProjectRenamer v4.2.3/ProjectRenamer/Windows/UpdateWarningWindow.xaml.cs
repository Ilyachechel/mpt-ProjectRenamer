﻿using System.Threading.Tasks;
using System.Windows;

namespace ProjectRenamer.Windows
{
    public partial class UpdateWarningWindow : Window
    {
        public UpdateWarningWindow()
        {
            InitializeComponent();
            AutoCloseAsync();
        }

        private async void AutoCloseAsync()
        {
            // Ждём 2 секунды, чтобы пользователь успел прочитать
            await Task.Delay(2000);
            this.Close();
        }
    }
}