﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;

namespace ProjectRenamer.Helpers
{
    public static class UpdateChecker
    {
        // 👇 ЗАМЕНИ НА СВОИ ДАННЫЕ
        private const string REPO_OWNER = "ilyachechel";
        private const string REPO_NAME = "mpt-ProjectRenamer";

        public static async Task<UpdateInfo> CheckAsync(bool includePrereleases = false)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("User-Agent", "ProjectRenamer-Updater");

                    string url = includePrereleases
                        ? $"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/releases?per_page=1"
                        : $"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/releases/latest";

                    var json = await client.GetStringAsync(url);

                    // Для предрелизов берём первый элемент массива
                    string data = includePrereleases ? ExtractJsonArrayItem(json, 0) : json;
                    if (string.IsNullOrEmpty(data)) return null;

                    var tagName = ExtractJsonValue(data, "tag_name");
                    var downloadUrl = ExtractAssetUrl(data, ".zip", "Source code");
                    var notes = ExtractJsonValue(data, "body");

                    if (string.IsNullOrEmpty(tagName) || string.IsNullOrEmpty(downloadUrl))
                        return null;

                    var current = VersionHelper.GetCurrentVersion();
                    var latest = tagName.TrimStart('v', 'V');

                    return VersionHelper.CompareVersions(latest, current) > 0
                        ? new UpdateInfo { LatestVersion = latest, DownloadUrl = downloadUrl, ReleaseNotes = notes }
                        : null;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Update check failed: {ex.Message}");
                return null;
            }
        }

        public static async Task<bool> DownloadAndInstallAsync(UpdateInfo info, IProgress<double> progress = null)
        {
            try
            {
                var tempDir = Path.Combine(Path.GetTempPath(), "PR_Update_" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(tempDir);
                var zipPath = Path.Combine(tempDir, "update.zip");

                using (var client = new HttpClient())
                {
                    using (var response = await client.GetAsync(info.DownloadUrl))
                    {
                        response.EnsureSuccessStatusCode();
                        var total = response.Content.Headers.ContentLength ?? 0;
                        var downloaded = 0L;

                        using (var stream = await response.Content.ReadAsStreamAsync())
                        using (var file = new FileStream(zipPath, FileMode.Create, FileAccess.Write, FileShare.None))
                        {
                            var buffer = new byte[81920];
                            int read;
                            while ((read = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                            {
                                await file.WriteAsync(buffer, 0, read);
                                downloaded += read;
                                if (progress != null && total > 0)
                                    progress.Report((double)downloaded / total * 100);
                            }
                        }
                    }
                }

                using (var fs = new FileStream(zipPath, FileMode.Open, FileAccess.Read))
                    if (fs.Length < 4 || fs.ReadByte() != 0x50 || fs.ReadByte() != 0x4B)
                        throw new InvalidDataException("Скачанный файл не является ZIP-архивом.");

                var extractDir = Path.Combine(tempDir, "extracted");
                ZipFile.ExtractToDirectory(zipPath, extractDir);

                string newExePath = Directory.GetFiles(extractDir, "ProjectRenamer.exe", SearchOption.AllDirectories).FirstOrDefault();
                if (string.IsNullOrEmpty(newExePath))
                    throw new FileNotFoundException("В архиве не найден ProjectRenamer.exe");

                var appDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                var targetExe = Path.Combine(appDir, "ProjectRenamer.exe");
                var batPath = Path.Combine(Path.GetTempPath(), "_pr_update.cmd");

                //  Железобетонный батник
                string batContent = $@"@echo off
setlocal
set ""TARGET={targetExe}""
set ""SOURCE={newExePath}""
set ""TEMPDIR={tempDir}""

:: 1. Гарантированно снимаем блокировку файла
taskkill /F /IM ProjectRenamer.exe >nul 2>&1
ping 127.0.0.1 -n 3 >nul

:: 2. Цикл копирования с проверкой
for /L %%i in (1,1,10) do (
    ping 127.0.0.1 -n 2 >nul
    copy /Y ""%SOURCE%"" ""%TARGET%"" >nul 2>&1
    if errorlevel 0 if not errorlevel 1 goto success
)
echo Failed to update. & pause & exit /b

:success
:: 3. Запуск новой версии
start """" ""%TARGET%""
ping 127.0.0.1 -n 2 >nul

:: 4. Очистка временных файлов
rd /s /q ""%TEMPDIR%"" >nul 2>&1
del ""%~f0"" >nul 2>&1
exit /b";

                File.WriteAllText(batPath, batContent, System.Text.Encoding.ASCII);

                var psi = new ProcessStartInfo(batPath)
                {
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    Verb = "runas" // Запуск от имени текущего пользователя (без UAC, если не админ)
                };
                Process.Start(psi);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления:\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }
        private static void CopyDirectory(string sourceDir, string targetDir)
        {
            Directory.CreateDirectory(targetDir);

            foreach (var file in Directory.GetFiles(sourceDir, "*.*", SearchOption.AllDirectories))
            {
                // Совместимая замена для Path.GetRelativePath
                var relPath = file.Substring(sourceDir.Length + 1);
                var destPath = Path.Combine(targetDir, relPath);
                var destDir = Path.GetDirectoryName(destPath);

                if (!string.IsNullOrEmpty(destDir) && !Directory.Exists(destDir))
                    Directory.CreateDirectory(destDir);

                try
                {
                    File.Copy(file, destPath, true);
                }
                catch
                {
                    // Файл используется или защищён — пропускаем
                }
            }
        }

        private static string ExtractJsonValue(string json, string key)
        {
            var searchKey = "\"" + key + "\"";
            var startIndex = json.IndexOf(searchKey, StringComparison.Ordinal);
            if (startIndex == -1) return null;

            var valueStart = json.IndexOf(':', startIndex) + 1;
            while (valueStart < json.Length && (json[valueStart] == ' ' || json[valueStart] == '"'))
                valueStart++;

            var isString = valueStart > 0 && json[valueStart - 1] == '"';
            if (isString)
            {
                var endIndex = json.IndexOf('"', valueStart);
                return endIndex == -1 ? null : json.Substring(valueStart, endIndex - valueStart);
            }
            else
            {
                var commaIdx = json.IndexOf(',', valueStart);
                var braceIdx = json.IndexOf('}', valueStart);
                var endIndex = Math.Min(
                    commaIdx != -1 ? commaIdx : int.MaxValue,
                    braceIdx != -1 ? braceIdx : int.MaxValue);
                return json.Substring(valueStart, endIndex - valueStart).Trim();
            }
        }

        private static string ExtractJsonArrayItem(string json, int index)
        {
            int pos = 0;
            for (int i = 0; i <= index; i++)
            {
                pos = json.IndexOf('{', pos);
                if (pos == -1) return null;
                if (i < index) pos++;
            }
            int end = json.IndexOf('}', pos);
            return end == -1 ? null : json.Substring(pos, end - pos + 1);
        }

        private static string ExtractAssetUrl(string json, string extension, string excludeKeyword)
        {
            int idx = 0;
            while (true)
            {
                idx = json.IndexOf("\"browser_download_url\"", idx, StringComparison.Ordinal);
                if (idx == -1) return null;

                int urlStart = json.IndexOf('"', idx + 22) + 1;
                int urlEnd = json.IndexOf('"', urlStart);
                string url = json.Substring(urlStart, urlEnd - urlStart);

                if (url.EndsWith(extension, StringComparison.OrdinalIgnoreCase) &&
                    url.IndexOf(excludeKeyword, StringComparison.OrdinalIgnoreCase) == -1)
                    return url;

                idx = urlEnd;
            }
        }

    }

    public class UpdateInfo
    {
        public string LatestVersion { get; set; }
        public string DownloadUrl { get; set; }
        public string ReleaseNotes { get; set; }
    }

    // Вспомогательный класс для работы с версиями
    public static class VersionHelper
    {
        // ✅ Новое свойство для отображения в UI
        public static string DisplayVersion => $"v{GetCurrentVersion()}";

        public static string GetCurrentVersion()
        {
            var version = Assembly.GetExecutingAssembly().GetName().Version;
            return string.Format("{0}.{1}.{2}", version.Major, version.Minor, version.Build);
        }

        public static int CompareVersions(string v1, string v2)
        {
            var parts1 = v1.Split('.').Select(s => { int n; return int.TryParse(s, out n) ? n : 0; }).ToArray();
            var parts2 = v2.Split('.').Select(s => { int n; return int.TryParse(s, out n) ? n : 0; }).ToArray();

            for (int i = 0; i < Math.Max(parts1.Length, parts2.Length); i++)
            {
                var p1 = i < parts1.Length ? parts1[i] : 0;
                var p2 = i < parts2.Length ? parts2[i] : 0;
                if (p1 > p2) return 1;
                if (p1 < p2) return -1;
            }
            return 0;
        }
    }
}