﻿using System.Windows;
using System.Windows.Input;

namespace ProjectRenamer.Windows
{
    public partial class UpdatePromptWindow : Window
    {
        public UpdatePromptWindow(Helpers.UpdateInfo info)
        {
            InitializeComponent();
            txtVersion.Text = info.LatestVersion;
            txtNotes.Text = string.IsNullOrEmpty(info.ReleaseNotes) ? "Список изменений не указан." : info.ReleaseNotes;
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Перетаскивание сработает только при клике по пустой области.
            // Клик по кнопкам/полям ввода будет игнорироваться (WPF routing).
            if (e.ChangedButton == MouseButton.Left && e.ButtonState == MouseButtonState.Pressed)
            {
                this.DragMove();
            }
        }
    }
}