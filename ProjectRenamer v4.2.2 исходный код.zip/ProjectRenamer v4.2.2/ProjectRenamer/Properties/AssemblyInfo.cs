using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("ProjectRenamer")]
[assembly: AssemblyDescription("Переименование проектов C#")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("МПТ")]
[assembly: AssemblyProduct("ProjectRenamer")]
[assembly: AssemblyCopyright("Copyright © 2024")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyVersion("4.2.2.0")]
[assembly: AssemblyFileVersion("4.2.2.0")]