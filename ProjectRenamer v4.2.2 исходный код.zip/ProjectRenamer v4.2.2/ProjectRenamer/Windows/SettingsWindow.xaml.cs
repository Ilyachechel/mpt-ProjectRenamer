﻿using ProjectRenamer.Helpers;
using ProjectRenamer.Models;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace ProjectRenamer.Windows
{
    public partial class SettingsWindow : Window
    {
        public AppSettings UpdatedSettings { get; private set; }
        private AppSettings _originalSettings;

        public SettingsWindow(AppSettings settings)
        {
            InitializeComponent();
            _originalSettings = settings;
            LoadSettingsToUI();
        }

        private void LoadSettingsToUI()
        {
            chkDarkTheme.IsChecked = _originalSettings.IsDarkTheme;
            chkAutoFill.IsChecked = _originalSettings.AutoFillNames;
            chkIgnoreMedia.IsChecked = _originalSettings.IgnoreMediaFiles;
            chkIgnoreBuild.IsChecked = _originalSettings.IgnoreBuildFolders;

            cmbUpdateMode.SelectedIndex = _originalSettings.UpdateCheckMode;
            chkPreReleases.IsChecked = _originalSettings.IncludePrereleases;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            UpdatedSettings = new AppSettings
            {
                IsDarkTheme = chkDarkTheme.IsChecked ?? false,
                AutoFillNames = chkAutoFill.IsChecked ?? true,
                IgnoreMediaFiles = chkIgnoreMedia.IsChecked ?? true,
                IgnoreBuildFolders = chkIgnoreBuild.IsChecked ?? true,
                UpdateCheckMode = cmbUpdateMode.SelectedIndex,
                IncludePrereleases = chkPreReleases.IsChecked ?? false
            };
            DialogResult = true;
            Close();
        }

        private async void BtnCheckUpdates_Click(object sender, RoutedEventArgs e)
        {
            txtUpdateStatus.Text = "Проверка...";
            var includeBeta = chkPreReleases.IsChecked ?? false;
            var updates = await UpdateChecker.CheckAllUpdatesAsync(includeBeta);

            if (updates == null)
            {
                txtUpdateStatus.Text = "✅ Установлена последняя версия";
                ShowCustomDialog("✅ Всё актуально",
                    "У вас последняя версия " + VersionHelper.GetCurrentVersion() + ".\nНовых обновлений нет.");
            }
            else
            {
                txtUpdateStatus.Text = "";
                var prompt = new UpdatePromptWindow(updates);
                if (prompt.ShowDialog() == true)
                {
                    await InstallUpdate(prompt.LatestUpdate);
                }
            }
        }

        private async System.Threading.Tasks.Task InstallUpdate(UpdateInfo update)
        {
            txtUpdateStatus.Text = "Скачивание...";
            this.IsEnabled = false;

            var success = await UpdateChecker.DownloadAndInstallAsync(update,
                new Progress<double>(p => txtUpdateStatus.Text = "Загрузка: " + p.ToString("F0") + "%"));

            if (success)
            {
                var warning = new UpdateWarningWindow();
                warning.Show();
                await Task.Delay(100);
                Environment.Exit(0);
            }
            else
            {
                this.IsEnabled = true;
                txtUpdateStatus.Text = "❌ Ошибка установки";
            }
        }

        private void ShowCustomDialog(string title, string message)
        {
            var dialog = new CustomDialog(title, message);
            dialog.Owner = this;
            dialog.ShowDialog();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Перетаскивание сработает только при клике по пустой области.
            // Клик по кнопкам/полям ввода будет игнорироваться (WPF routing).
            if (e.ChangedButton == MouseButton.Left && e.ButtonState == MouseButtonState.Pressed)
            {
                this.DragMove();
            }
        }
    }
}