﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;

namespace ProjectRenamer.Helpers
{
    public static class UpdateChecker
    {
        // 👇 ЗАМЕНИ НА СВОИ ДАННЫЕ
        private const string REPO_OWNER = "ilyachechel";
        private const string REPO_NAME = "mpt-ProjectRenamer";

        public static async Task<List<UpdateInfo>> CheckAllUpdatesAsync(bool includePrereleases = false)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("User-Agent", "ProjectRenamer-Updater");

                    string url = $"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/releases?per_page=100";
                    var json = await client.GetStringAsync(url);

                    var currentVersion = VersionHelper.GetCurrentVersion();
                    var updates = new List<UpdateInfo>();

                    // Парсим все релизы из массива
                    int pos = 0;
                    while (true)
                    {
                        pos = json.IndexOf("{", pos, StringComparison.Ordinal);
                        if (pos == -1) break;

                        int end = FindMatchingBrace(json, pos);
                        if (end == -1) break;

                        string releaseJson = json.Substring(pos, end - pos + 1);
                        pos = end + 1;

                        var tagName = ExtractJsonValue(releaseJson, "tag_name");
                        var downloadUrl = ExtractAssetUrl(releaseJson, ".zip", "Source code");
                        var notes = ExtractJsonValue(releaseJson, "body");
                        var isPrerelease = ExtractJsonValue(releaseJson, "prerelease");

                        if (string.IsNullOrEmpty(tagName) || string.IsNullOrEmpty(downloadUrl))
                            continue;

                        // Пропускаем предрелизы если не нужно
                        if (!includePrereleases && isPrerelease == "true")
                            continue;

                        var latestVersion = tagName.TrimStart('v', 'V');

                        if (VersionHelper.CompareVersions(latestVersion, currentVersion) > 0)
                        {
                            updates.Add(new UpdateInfo
                            {
                                LatestVersion = latestVersion,
                                DownloadUrl = downloadUrl,
                                ReleaseNotes = notes
                            });
                        }
                    }

                    // Сортируем по версии (от старой к новой)
                    updates.Sort((a, b) => VersionHelper.CompareVersions(a.LatestVersion, b.LatestVersion));

                    return updates.Count > 0 ? updates : null;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Update check failed: {ex.Message}");
                return null;
            }
        }

        // Вспомогательный метод для поиска закрывающей скобки
        private static int FindMatchingBrace(string json, int startPos)
        {
            int depth = 0;
            bool inString = false;

            for (int i = startPos; i < json.Length; i++)
            {
                char c = json[i];

                if (c == '"' && (i == 0 || json[i - 1] != '\\'))
                    inString = !inString;

                if (!inString)
                {
                    if (c == '{') depth++;
                    else if (c == '}')
                    {
                        depth--;
                        if (depth == 0) return i;
                    }
                }
            }
            return -1;
        }

        public static async Task<bool> DownloadAndInstallAsync(UpdateInfo info, IProgress<double> progress = null)
        {
            try
            {
                var tempDir = Path.Combine(Path.GetTempPath(), "PR_Update_" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(tempDir);
                var zipPath = Path.Combine(tempDir, "update.zip");

                using (var client = new HttpClient())
                {
                    using (var response = await client.GetAsync(info.DownloadUrl))
                    {
                        response.EnsureSuccessStatusCode();
                        var total = response.Content.Headers.ContentLength ?? 0;
                        var downloaded = 0L;

                        using (var stream = await response.Content.ReadAsStreamAsync())
                        using (var file = new FileStream(zipPath, FileMode.Create, FileAccess.Write, FileShare.None))
                        {
                            var buffer = new byte[81920];
                            int read;
                            while ((read = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                            {
                                await file.WriteAsync(buffer, 0, read);
                                downloaded += read;
                                if (progress != null && total > 0)
                                    progress.Report((double)downloaded / total * 100);
                            }
                        }
                    }
                }

                using (var fs = new FileStream(zipPath, FileMode.Open, FileAccess.Read))
                    if (fs.Length < 4 || fs.ReadByte() != 0x50 || fs.ReadByte() != 0x4B)
                        throw new InvalidDataException("Скачанный файл не является ZIP-архивом.");

                var extractDir = Path.Combine(tempDir, "extracted");
                ZipFile.ExtractToDirectory(zipPath, extractDir);

                string newExePath = Directory.GetFiles(extractDir, "ProjectRenamer.exe", SearchOption.AllDirectories).FirstOrDefault();
                if (string.IsNullOrEmpty(newExePath))
                    throw new FileNotFoundException("В архиве не найден ProjectRenamer.exe");

                var appDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                var targetExe = Path.Combine(appDir, "ProjectRenamer.exe");
                var batPath = Path.Combine(Path.GetTempPath(), "_pr_update.cmd");

                // ✅ Батник с поддержкой кириллицы и спецсимволов
                string batContent = $@"@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion

set ""TARGET={targetExe}""
set ""SOURCE={newExePath}""
set ""TEMPDIR={tempDir}""

:: Снимаем блокировку с процесса
taskkill /F /IM ProjectRenamer.exe >nul 2>&1
ping 127.0.0.1 -n 3 >nul

:: Цикл копирования с проверкой (до 15 попыток)
for /L %%i in (1,1,15) do (
    ping 127.0.0.1 -n 2 >nul
    copy /Y ""!SOURCE!"" ""!TARGET!"" >nul 2>&1
    if not errorlevel 1 goto success
)
echo Failed to update. & pause & exit /b

:success
:: Запуск новой версии
start """" ""!TARGET!""
ping 127.0.0.1 -n 2 >nul

:: Очистка
rd /s /q ""!TEMPDIR!"" >nul 2>&1
del ""%~f0"" >nul 2>&1
exit /b";

                // ✅ Записываем в UTF-8 с BOM — cmd.exe поймёт кириллицу после chcp 65001
                File.WriteAllText(batPath, batContent, new System.Text.UTF8Encoding(true));

                // ✅ Запускаем через cmd.exe для корректной работы с путями
                var psi = new ProcessStartInfo("cmd.exe")
                {
                    Arguments = $"/c \"{batPath}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                Process.Start(psi);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления:\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        private static void CopyDirectory(string sourceDir, string targetDir)
        {
            Directory.CreateDirectory(targetDir);

            foreach (var file in Directory.GetFiles(sourceDir, "*.*", SearchOption.AllDirectories))
            {
                // Совместимая замена для Path.GetRelativePath
                var relPath = file.Substring(sourceDir.Length + 1);
                var destPath = Path.Combine(targetDir, relPath);
                var destDir = Path.GetDirectoryName(destPath);

                if (!string.IsNullOrEmpty(destDir) && !Directory.Exists(destDir))
                    Directory.CreateDirectory(destDir);

                try
                {
                    File.Copy(file, destPath, true);
                }
                catch
                {
                    // Файл используется или защищён — пропускаем
                }
            }
        }

        private static string ExtractJsonValue(string json, string key)
        {
            var searchKey = "\"" + key + "\"";
            var startIndex = json.IndexOf(searchKey, StringComparison.Ordinal);
            if (startIndex == -1) return null;

            var valueStart = json.IndexOf(':', startIndex) + 1;
            while (valueStart < json.Length && (json[valueStart] == ' ' || json[valueStart] == '"'))
                valueStart++;

            var isString = valueStart > 0 && json[valueStart - 1] == '"';
            if (isString)
            {
                var endIndex = json.IndexOf('"', valueStart);
                return endIndex == -1 ? null : json.Substring(valueStart, endIndex - valueStart);
            }
            else
            {
                var commaIdx = json.IndexOf(',', valueStart);
                var braceIdx = json.IndexOf('}', valueStart);
                var endIndex = Math.Min(
                    commaIdx != -1 ? commaIdx : int.MaxValue,
                    braceIdx != -1 ? braceIdx : int.MaxValue);
                return json.Substring(valueStart, endIndex - valueStart).Trim();
            }
        }

        private static string ExtractJsonArrayItem(string json, int index)
        {
            int pos = 0;
            for (int i = 0; i <= index; i++)
            {
                pos = json.IndexOf('{', pos);
                if (pos == -1) return null;
                if (i < index) pos++;
            }
            int end = json.IndexOf('}', pos);
            return end == -1 ? null : json.Substring(pos, end - pos + 1);
        }

        private static string ExtractAssetUrl(string json, string extension, string excludeKeyword)
        {
            int idx = 0;
            while (true)
            {
                idx = json.IndexOf("\"browser_download_url\"", idx, StringComparison.Ordinal);
                if (idx == -1) return null;

                int urlStart = json.IndexOf('"', idx + 22) + 1;
                int urlEnd = json.IndexOf('"', urlStart);
                string url = json.Substring(urlStart, urlEnd - urlStart);

                if (url.EndsWith(extension, StringComparison.OrdinalIgnoreCase) &&
                    url.IndexOf(excludeKeyword, StringComparison.OrdinalIgnoreCase) == -1)
                    return url;

                idx = urlEnd;
            }
        }

    }

    public class UpdateInfo
    {
        public string LatestVersion { get; set; }
        public string DownloadUrl { get; set; }
        public string ReleaseNotes { get; set; }
    }

    // Вспомогательный класс для работы с версиями
    public static class VersionHelper
    {
        // ✅ Новое свойство для отображения в UI
        public static string DisplayVersion => $"v{GetCurrentVersion()}";

        public static string GetCurrentVersion()
        {
            var version = Assembly.GetExecutingAssembly().GetName().Version;
            return string.Format("{0}.{1}.{2}", version.Major, version.Minor, version.Build);
        }

        public static int CompareVersions(string v1, string v2)
        {
            var parts1 = v1.Split('.').Select(s => { int n; return int.TryParse(s, out n) ? n : 0; }).ToArray();
            var parts2 = v2.Split('.').Select(s => { int n; return int.TryParse(s, out n) ? n : 0; }).ToArray();

            for (int i = 0; i < Math.Max(parts1.Length, parts2.Length); i++)
            {
                var p1 = i < parts1.Length ? parts1[i] : 0;
                var p2 = i < parts2.Length ? parts2[i] : 0;
                if (p1 > p2) return 1;
                if (p1 < p2) return -1;
            }
            return 0;
        }
    }
}