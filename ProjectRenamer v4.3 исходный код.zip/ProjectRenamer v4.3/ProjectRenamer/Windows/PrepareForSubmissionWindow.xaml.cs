﻿using Microsoft.Win32;
using ProjectRenamer.Helpers;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace ProjectRenamer.Windows
{
    public partial class PrepareForSubmissionWindow : Window
    {
        private List<string> _extraFiles = new List<string>();
        private string _archiveNameTemplate = "09.02.07-ИС.ОАиП.[Группа].[ФИО].ПР00";
        public PrepareForSubmissionWindow()
        {
            InitializeComponent();

            // Автоматическое обновление имени архива при изменении группы и ФИО
            txtGroup.TextChanged += (s, e) => UpdateArchiveName();
            txtFullName.TextChanged += (s, e) => UpdateArchiveName();

            // По умолчанию - рабочий стол
            txtOutputFolder.Text = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            // Обработка drag & drop для полей
            txtProjectPath.AllowDrop = true;
            txtProjectPath.PreviewDragOver += TxtProjectPath_DragOver;
            txtProjectPath.PreviewDrop += TxtProjectPath_Drop;

            txtReportPath.AllowDrop = true;
            txtReportPath.PreviewDragOver += TxtReportPath_DragOver;
            txtReportPath.PreviewDrop += TxtReportPath_Drop;
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left && e.ButtonState == MouseButtonState.Pressed)
                this.DragMove();
        }

        #region Project Path
        private void TxtProjectPath_Click(object sender, MouseButtonEventArgs e)
        {
            BtnBrowseProject_Click(sender, null);
        }

        private void BtnBrowseProject_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Solution Files|*.sln;*.slnx|All Files|*.*",
                Title = "Выберите файл проекта"
            };
            if (dialog.ShowDialog() == true)
            {
                txtProjectPath.Text = dialog.FileName;
                AutoFillPracticeNumber(dialog.FileName);
            }
        }

        private void TxtProjectPath_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0 &&
                    (files[0].EndsWith(".sln", StringComparison.OrdinalIgnoreCase) ||
                     files[0].EndsWith(".slnx", StringComparison.OrdinalIgnoreCase)))
                {
                    e.Effects = DragDropEffects.Copy;
                    e.Handled = true;
                    return;
                }
            }
            e.Effects = DragDropEffects.None;
            e.Handled = true;
        }

        private void TxtProjectPath_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0)
                {
                    txtProjectPath.Text = files[0];
                    AutoFillPracticeNumber(files[0]);
                    e.Handled = true;
                }
            }
        }
        #endregion

        #region Report Path
        private void TxtReportPath_Click(object sender, MouseButtonEventArgs e)
        {
            BtnBrowseReport_Click(sender, null);
        }

        private void BtnBrowseReport_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Word Documents|*.doc;*.docx|All Files|*.*",
                Title = "Выберите файл отчета"
            };
            if (dialog.ShowDialog() == true)
            {
                txtReportPath.Text = dialog.FileName;
            }
        }

        private void TxtReportPath_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0 &&
                    (files[0].EndsWith(".doc", StringComparison.OrdinalIgnoreCase) ||
                     files[0].EndsWith(".docx", StringComparison.OrdinalIgnoreCase)))
                {
                    e.Effects = DragDropEffects.Copy;
                    e.Handled = true;
                    return;
                }
            }
            e.Effects = DragDropEffects.None;
            e.Handled = true;
        }

        private void TxtReportPath_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0)
                {
                    txtReportPath.Text = files[0];
                    e.Handled = true;
                }
            }
        }
        #endregion

        #region Extra Files
        private void BtnAddExtraFiles_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "All Files|*.*",
                Title = "Выберите дополнительные файлы",
                Multiselect = true
            };
            if (dialog.ShowDialog() == true)
            {
                _extraFiles.AddRange(dialog.FileNames);
                txtExtraFiles.Text = $"Выбрано файлов: {_extraFiles.Count}";
            }
        }
        #endregion

        #region Output Folder
        private void BtnBrowseOutput_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Выберите папку для сохранения архива",
                SelectedPath = txtOutputFolder.Text
            };
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtOutputFolder.Text = dialog.SelectedPath;
            }
        }
        #endregion

        private void UpdateArchiveName()
        {
            var group = txtGroup.Text.Trim();
            var fullName = txtFullName.Text.Trim();

            // Убираем точку в конце ФИО если есть
            if (fullName.EndsWith("."))
                fullName = fullName.Substring(0, fullName.Length - 1);

            // Убираем пробелы после точек в инициалах
            fullName = System.Text.RegularExpressions.Regex.Replace(fullName, @"\. ", ".");

            // Заменяем плейсхолдеры на реальные значения
            var archiveName = _archiveNameTemplate
                .Replace("[Группа]", string.IsNullOrEmpty(group) ? "[Группа]" : group)
                .Replace("[ФИО]", string.IsNullOrEmpty(fullName) ? "[ФИО]" : fullName);

            txtArchiveName.Text = archiveName;
        }

        #region Auto-fill Practice Number
        private void AutoFillPracticeNumber(string projectPath)
        {
            var fileName = Path.GetFileNameWithoutExtension(projectPath);
            var parser = new ProjectNameParser(fileName);
    
            if (parser.IsValid)
            {
                _archiveNameTemplate = $"09.02.07-ИС.ОАиП.[Группа].[ФИО].ПР{parser.PracticeNumber:00}";
            }
            else
            {
                _archiveNameTemplate = "09.02.07-ИС.ОАиП.[Группа].[ФИО].ПР00";
            }
    
            UpdateArchiveName();
        }
        #endregion

        private void BtnCreateZip_Click(object sender, RoutedEventArgs e)
        {
            // Валидация обязательных полей
            if (string.IsNullOrWhiteSpace(txtProjectPath.Text))
            {
                ShowError("Пожалуйста, выберите файл проекта (.sln/.slnx)");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtReportPath.Text))
            {
                ShowError("Пожалуйста, выберите файл отчета (.doc/.docx)");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtFullName.Text))
            {
                ShowError("Пожалуйста, введите ФИО");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtGroup.Text))
            {
                ShowError("Пожалуйста, введите группу");
                return;
            }

            try
            {
                var projectPath = txtProjectPath.Text;
                var reportPath = txtReportPath.Text;
                var archiveName = txtArchiveName.Text;

                var outputFolder = txtOutputFolder.Text;
                var zipPath = Path.Combine(outputFolder, archiveName + ".zip");

                // Создаем ZIP
                using (var zip = ZipFile.Open(zipPath, ZipArchiveMode.Create))
                {
                    // ✅ Имя папки внутри архива = имя исходного проекта (без расширения .sln/.slnx)
                    var folderName = Path.GetFileNameWithoutExtension(projectPath);

                    // 1. Отчет и доп. файлы кидаем в КОРЕНЬ архива (без папки)
                    AddFileToZip(zip, reportPath, Path.GetFileName(reportPath));

                    foreach (var file in _extraFiles)
                    {
                        AddFileToZip(zip, file, Path.GetFileName(file));
                    }

                    // 2. Сам проект кидаем ВНУТРЬ папки с именем проекта
                    var projectDir = Path.GetDirectoryName(projectPath);
                    if (Directory.Exists(projectDir))
                    {
                        AddDirectoryToZip(zip, projectDir, folderName, chkIgnoreBin.IsChecked ?? false);
                    }
                }

                ShowCustomDialog("✅ Готово!",
                    $"Архив успешно создан!\n\n📍 {zipPath}");

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка создания архива:\n{ex.Message}");
            }
        }

        private void AddFileToZip(ZipArchive zip, string filePath, string entryName)
        {
            if (File.Exists(filePath))
            {
                zip.CreateEntryFromFile(filePath, entryName, CompressionLevel.Optimal);
            }
        }

        private void AddDirectoryToZip(ZipArchive zip, string sourceDir, string rootFolder, bool ignoreBin)
        {
            var ignoredFolders = new[] { ".vs", "obj", "packages", ".git", "node_modules" };
            if (ignoreBin) ignoredFolders = ignoredFolders.Concat(new[] { "bin" }).ToArray();

            foreach (var file in Directory.GetFiles(sourceDir, "*.*", SearchOption.AllDirectories))
            {
                var relativePath = file.Substring(sourceDir.Length + 1);
                var parts = relativePath.Split('\\');

                // Проверяем игнорируемые папки
                bool shouldIgnore = false;
                foreach (var part in parts)
                {
                    if (ignoredFolders.Any(f => part.Equals(f, StringComparison.OrdinalIgnoreCase)))
                    {
                        shouldIgnore = true;
                        break;
                    }
                }

                if (!shouldIgnore)
                {
                    var entryName = $"{rootFolder}\\{relativePath}";
                    zip.CreateEntryFromFile(file, entryName, CompressionLevel.Optimal);
                }
            }
        }

        private void ShowError(string message)
        {
            ShowCustomDialog("⚠️ Внимание", message);
        }

        private void ShowCustomDialog(string title, string message)
        {
            var dialog = new CustomDialog(title, message);
            dialog.Owner = this;
            dialog.ShowDialog();
        }
    }
}