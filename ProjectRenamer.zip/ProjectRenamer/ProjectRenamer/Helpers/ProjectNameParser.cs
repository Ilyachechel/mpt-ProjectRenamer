using System.Text.RegularExpressions;

namespace ProjectRenamer.Helpers
{
    public class ProjectNameParser
    {
        public string OriginalName { get; }
        public int PracticeNumber { get; }
        public int VariantNumber { get; }
        public bool IsValid { get; }
        private static readonly Regex Pattern = new Regex(@"^wfPr(\d{1,2})_Var(\d{1,2})$", RegexOptions.IgnoreCase);

        public ProjectNameParser(string projectName)
        {
            OriginalName = projectName;
            var match = Pattern.Match(projectName);
            if (match.Success && int.TryParse(match.Groups[1].Value, out var pr) && 
                              int.TryParse(match.Groups[2].Value, out var vr))
            {
                PracticeNumber = pr; VariantNumber = vr; IsValid = true;
            }
            else { PracticeNumber = 0; VariantNumber = 0; IsValid = false; }
        }
    }
}