using System.IO;

namespace ProjectRenamer.Helpers
{
    public static class FileHelper
    {
        public static void RenameFile(string filePath, string oldText, string newText)
        {
            if (!File.Exists(filePath)) return;
            var directory = Path.GetDirectoryName(filePath);
            var fileName = Path.GetFileName(filePath);
            if (fileName.Contains(oldText))
            {
                var newFileName = fileName.Replace(oldText, newText);
                var newPath = Path.Combine(directory, newFileName);
                if (File.Exists(newPath)) File.Delete(newPath);
                File.Move(filePath, newPath);
            }
        }
    }
}