﻿using System;
using System.Windows;
using System.Windows.Media;

namespace ProjectRenamer.Helpers
{
    public static class ThemeHelper
    {
        public static void ApplyAccentColor(string hexColor)
        {
            try
            {
                var color = (Color)ColorConverter.ConvertFromString(hexColor);
                var darkerColor = Color.FromRgb(
                    (byte)Math.Max(0, color.R - 20),
                    (byte)Math.Max(0, color.G - 20),
                    (byte)Math.Max(0, color.B - 20));

                // Создаём новые экземпляры (не замороженные)
                var brush = new SolidColorBrush(color);
                var gradient = new LinearGradientBrush
                {
                    StartPoint = new Point(0, 0),
                    EndPoint = new Point(1, 1)
                };
                gradient.GradientStops.Add(new GradientStop(color, 0));
                gradient.GradientStops.Add(new GradientStop(darkerColor, 1));

                // Заменяем в глобальных ресурсах приложения
                Application.Current.Resources["PrimaryColor"] = brush;
                Application.Current.Resources["PrimaryGradient"] = gradient;
            }
            catch { /* Игнорируем ошибки парсинга HEX */ }
        }
    }
}