using Microsoft.Win32;
using ProjectRenamer.Helpers;
using ProjectRenamer.Models;
using ProjectRenamer.Windows;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ProjectRenamer
{
    public partial class MainWindow : Window
    {
        private AppSettings _settings;

        public MainWindow()
        {
            InitializeComponent();
            LoadSettings();
            ApplyTheme();
        }

        private void LoadSettings()
        {
            _settings = AppSettings.Load();
            // ✅ ТемаHelper убран
            ApplyTheme();
        }

        private void ApplyTheme()
        {
            bool isDark = _settings.IsDarkTheme;

            // Светлая тема
            var appBg = isDark ? Color.FromRgb(30, 30, 46) : Color.FromRgb(248, 249, 250);
            var contBg = isDark ? Color.FromRgb(40, 40, 58) : Color.FromRgb(255, 255, 255);
            var txtPri = isDark ? Color.FromRgb(236, 240, 241) : Color.FromRgb(44, 62, 80);
            var txtSec = isDark ? Color.FromRgb(140, 145, 155) : Color.FromRgb(102, 102, 102);
            var inpBg = isDark ? Color.FromRgb(50, 50, 70) : Color.FromRgb(255, 255, 255);
            var inpBrd = isDark ? Color.FromRgb(70, 70, 90) : Color.FromRgb(224, 224, 224);

            // Обновляем глобальные ресурсы (сработает для всех DynamicResource)
            Application.Current.Resources["AppBackground"] = new SolidColorBrush(appBg);
            Application.Current.Resources["ContainerBackground"] = new SolidColorBrush(contBg);
            Application.Current.Resources["TextPrimary"] = new SolidColorBrush(txtPri);
            Application.Current.Resources["TextSecondary"] = new SolidColorBrush(txtSec);
            Application.Current.Resources["InputBackground"] = new SolidColorBrush(inpBg);
            Application.Current.Resources["InputBorder"] = new SolidColorBrush(inpBrd);

            this.Background = (Brush)Application.Current.Resources["AppBackground"];
        }

        #region Drag & Drop (РАБОТАЮЩАЯ ВЕРСИЯ)
        private void Container_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0 &&
                   (files[0].EndsWith(".sln", StringComparison.OrdinalIgnoreCase) ||
                    files[0].EndsWith(".slnx", StringComparison.OrdinalIgnoreCase)))
                {
                    e.Effects = DragDropEffects.Copy;
                    e.Handled = true;
                    return;
                }
            }
            e.Effects = DragDropEffects.None;
            e.Handled = true;
        }

        private void Container_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0)
                {
                    txtSolutionPath.Text = files[0];
                    AutoFillSearchReplace(files[0]);
                    e.Handled = true;
                }
            }
        }
        #endregion

        #region UI Handlers
        private void TxtSolutionPath_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            BtnBrowse_Click(sender, null);
            e.Handled = true;
        }

        private void BtnBrowse_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Solution Files|*.sln;*.slnx|All Files|*.*",
                Title = "Выберите файл решения"
            };
            if (dialog.ShowDialog() == true)
            {
                txtSolutionPath.Text = dialog.FileName;
                AutoFillSearchReplace(dialog.FileName);
            }
        }

        private void AutoFillSearchReplace(string solutionPath)
        {
            if (!_settings.AutoFillNames) return;

            var fileName = Path.GetFileNameWithoutExtension(solutionPath);
            var parser = new ProjectNameParser(fileName);

            if (parser.IsValid)
            {
                txtSearch.Text = parser.OriginalName;
                txtReplace.Text = $"wfPr{parser.PracticeNumber + 1:00}_Var{parser.VariantNumber:00}";

                ShowCustomDialog("✅ Автозаполнение",
                    $"Обнаружен шаблон: {parser.OriginalName}\nПредложено новое имя: {txtReplace.Text}\n\nМожете отредактировать поля вручную.");
            }
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) { }

        private async void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSolutionPath.Text))
            {
                ShowCustomDialog("⚠️ Внимание", "Пожалуйста, выберите файл решения (.sln/.slnx)");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtSearch.Text) || string.IsNullOrWhiteSpace(txtReplace.Text))
            {
                ShowCustomDialog("⚠️ Внимание", "Заполните поля «Найти» и «Заменить на»");
                return;
            }

            await StartCloningProcess();
        }

        private void BtnSettings_Click(object sender, RoutedEventArgs e)
        {
            var settingsWindow = new SettingsWindow(_settings);
            if (settingsWindow.ShowDialog() == true)
            {
                _settings = settingsWindow.UpdatedSettings;
                _settings.Save();
                ApplyTheme();
            }
        }

        private void BtnSupport_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.donationalerts.com/r/ilyachechel123");
        }

        private void BtnAbout_Click(object sender, RoutedEventArgs e)
        {
            var aboutWindow = new AboutWindow();
            aboutWindow.ShowDialog();
        }
        #endregion

        #region Core Logic: Clone & Replace
        private async Task StartCloningProcess()
        {
            progressBar.Visibility = Visibility.Visible;
            txtStatus.Text = "Клонирование проекта...";
            this.IsEnabled = false;

            try
            {
                string sourceSlnPath = txtSolutionPath.Text;
                string sourceDir = Path.GetDirectoryName(sourceSlnPath);
                string oldName = txtSearch.Text.Trim();
                string newName = txtReplace.Text.Trim();

                // Целевая папка создаётся рядом с исходной
                string targetDir = Path.Combine(Path.GetDirectoryName(sourceDir), newName);

                if (Directory.Exists(targetDir))
                {
                    ShowCustomDialog("⚠️ Внимание", $"Папка '{targetDir}' уже существует.\nУдалите её или выберите другое имя.");
                    return;
                }

                int copied = 0, modified = 0, ignored = 0;

                await Task.Run(() =>
                {
                    CopyAndRenameDirectory(sourceDir, targetDir, oldName, newName, ref copied, ref modified, ref ignored);
                });

                // Автоматически подставляем путь к новому .sln файлу
                string newSlnName = Path.GetFileName(sourceSlnPath).Replace(oldName, newName);
                txtSolutionPath.Text = Path.Combine(targetDir, newSlnName);

                ShowCustomDialog("✅ Готово!",
                    $"Проект успешно клонирован и переименован!\n\n" +
                    $"📂 Скопировано файлов: {copied}\n" +
                    $"🔄 Изменено содержимое: {modified}\n" +
                    $"⏭️ Пропущено (системные/мусор): {ignored}\n\n" +
                    $"📍 Новый проект: {targetDir}");

                txtStatus.Text = $"✅ Готово: {newName}";
            }
            catch (Exception ex)
            {
                ShowCustomDialog("❌ Ошибка", $"Произошла ошибка:\n{ex.Message}");
                txtStatus.Text = "❌ Ошибка выполнения";
            }
            finally
            {
                progressBar.Visibility = Visibility.Collapsed;
                this.IsEnabled = true;
            }
        }

        private void CopyAndRenameDirectory(string sourceDir, string targetDir, string oldName, string newName, ref int copied, ref int modified, ref int ignored)
        {
            var ignoredFolders = _settings.IgnoreBuildFolders
                ? new[] { ".vs", "obj", "bin", "packages", ".git", "node_modules" }
                : new string[0];

            var textExtensions = new[]
            { ".cs", ".csproj", ".sln", ".slnx", ".config", ".xml", ".json", ".txt",
      ".xaml", ".resx", ".md", ".html", ".js", ".css", ".props", ".targets", ".editorconfig" };

            Directory.CreateDirectory(targetDir);

            // 1. Обработка папок
            foreach (var dir in Directory.GetDirectories(sourceDir))
            {
                var dirName = Path.GetFileName(dir);

                if (Array.Exists(ignoredFolders, f => dirName.Equals(f, StringComparison.OrdinalIgnoreCase)))
                {
                    ignored++;
                    continue;
                }

                // ✅ Совместимо с .NET Framework 4.7.2
                var newDirName = dirName.Contains(oldName) ? dirName.Replace(oldName, newName) : dirName;

                var newDirPath = Path.Combine(targetDir, newDirName);
                CopyAndRenameDirectory(dir, newDirPath, oldName, newName, ref copied, ref modified, ref ignored);
            }

            // 2. Обработка файлов
            foreach (var file in Directory.GetFiles(sourceDir))
            {
                var fileName = Path.GetFileName(file);
                var ext = Path.GetExtension(file).ToLowerInvariant();

                // ✅ Совместимо с .NET Framework 4.7.2
                var newFileName = fileName.Contains(oldName) ? fileName.Replace(oldName, newName) : fileName;
                var newFilePath = Path.Combine(targetDir, newFileName);
                copied++;

                try
                {
                    // Текстовые файлы: читаем, заменяем, записываем
                    if (Array.Exists(textExtensions, e => e.Equals(ext, StringComparison.OrdinalIgnoreCase)))
                    {
                        string content = File.ReadAllText(file, System.Text.Encoding.UTF8);
                        if (content.Contains(oldName))
                        {
                            content = content.Replace(oldName, newName);
                            File.WriteAllText(newFilePath, content, System.Text.Encoding.UTF8);
                            modified++;
                        }
                        else
                        {
                            File.Copy(file, newFilePath, true);
                        }
                    }
                    else
                    {
                        // Бинарные/медиа файлы: копируем без изменений
                        File.Copy(file, newFilePath, true);
                    }
                }
                catch
                {
                    // Если файл заблокирован или недоступен — просто копируем его как есть
                    File.Copy(file, newFilePath, true);
                }
            }
        }
        #endregion

        private void ShowCustomDialog(string title, string message)
        {
            var dialog = new CustomDialog(title, message);
            dialog.Owner = this;
            dialog.ShowDialog();
        }

        #region Window Controls
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
        #endregion
    }
}