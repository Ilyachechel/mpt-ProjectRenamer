using System;
using System.IO;
using System.Xml.Serialization;

namespace ProjectRenamer.Models
{
    [Serializable]
    public class AppSettings
    {
        public string PrimaryColor { get; set; } = "#4A90E2";
        public bool IsDarkTheme { get; set; } = false;
        public bool AutoFillNames { get; set; } = true;
        public bool IgnoreMediaFiles { get; set; } = true;
        public bool IgnoreBuildFolders { get; set; } = true;

        private static string SettingsPath => 
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), 
                        "ProjectRenamer", "settings.xml");

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath));
                var serializer = new XmlSerializer(typeof(AppSettings));
                using (var writer = new StreamWriter(SettingsPath))
                    serializer.Serialize(writer, this);
            }
            catch { }
        }

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(SettingsPath))
                {
                    var serializer = new XmlSerializer(typeof(AppSettings));
                    using (var reader = new StreamReader(SettingsPath))
                        return (AppSettings)serializer.Deserialize(reader);
                }
            }
            catch { }
            return new AppSettings();
        }
    }
}