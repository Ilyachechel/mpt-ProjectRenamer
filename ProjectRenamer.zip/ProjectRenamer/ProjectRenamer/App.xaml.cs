using System.Windows;

namespace ProjectRenamer
{
    public partial class App : Application { }
}