using System.Windows;

namespace ProjectRenamer.Windows
{
    public partial class AboutWindow : Window
    {
        public AboutWindow() { InitializeComponent(); }
    }
}