﻿using ProjectRenamer.Models;
using System.Windows;

namespace ProjectRenamer.Windows
{
    public partial class SettingsWindow : Window
    {
        public AppSettings UpdatedSettings { get; private set; }
        private AppSettings _originalSettings;

        public SettingsWindow(AppSettings settings)
        {
            InitializeComponent();
            _originalSettings = settings;
            LoadSettingsToUI();
        }

        private void LoadSettingsToUI()
        {
            chkDarkTheme.IsChecked = _originalSettings.IsDarkTheme;
            chkAutoFill.IsChecked = _originalSettings.AutoFillNames;
            chkIgnoreMedia.IsChecked = _originalSettings.IgnoreMediaFiles;
            chkIgnoreBuild.IsChecked = _originalSettings.IgnoreBuildFolders;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            UpdatedSettings = new AppSettings
            {
                IsDarkTheme = chkDarkTheme.IsChecked ?? false,
                AutoFillNames = chkAutoFill.IsChecked ?? true,
                IgnoreMediaFiles = chkIgnoreMedia.IsChecked ?? true,
                IgnoreBuildFolders = chkIgnoreBuild.IsChecked ?? true
            };
            DialogResult = true;
            Close();
        }
    }
}