using System.Windows;

namespace ProjectRenamer.Windows
{
    public partial class CustomDialog : Window
    {
        public CustomDialog(string title, string message)
        {
            InitializeComponent();
            txtTitle.Text = title;
            txtMessage.Text = message;
        }
        private void BtnOk_Click(object sender, RoutedEventArgs e) { DialogResult = true; Close(); }
    }
}